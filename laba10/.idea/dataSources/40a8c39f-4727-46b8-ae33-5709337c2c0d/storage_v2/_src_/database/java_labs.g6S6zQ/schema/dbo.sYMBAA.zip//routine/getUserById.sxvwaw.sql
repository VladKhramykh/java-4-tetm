CREATE PROCEDURE [getUserById]
    @username nvarchar(50) output,
    @id integer
AS
BEGIN
    SET NOCOUNT ON;

    SELECT top(1) @username = username FROM users
    WHERE id = @id;
END
go

